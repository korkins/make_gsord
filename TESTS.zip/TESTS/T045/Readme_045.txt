Scenario:
    Emde C et al, 2015: IPRT polarized radiative transfer model intercomparison project � Phase A, JQSRT, v.164, pp.8-36.
    See p.26, Section 3.3.4, *** EXCEPT FOR RAYLEIGH IS OMITTED***

Comments:
    The benchmark result was generated with IPOL using NA=180 azimuth nodes to expand surface in Fourier series

