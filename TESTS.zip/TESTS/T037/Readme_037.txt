Scenario:
    Mishchenko MI, 1990: The fast invariant imbedding method for polarized light: computational aspects and numerical results for Rayleigh scattering, JQSRT, 43(2), pp.163-171.
    See Table 3, p.169, for results: SSA=exp(-g*Tau), Case g=0.0 (SSA = 1.0).

Comments:
    Dispite SSA is not a function of Tau, it is assumed NLR=NL in the test.







