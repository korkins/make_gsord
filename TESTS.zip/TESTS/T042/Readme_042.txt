Scenario:
    Wauben WMF and Hovenier JW, 1992: Polarized radiation of an atmosphere containing randomly-oriented spheroids, JQSRT, v.47(6), pp.491-504.
    See pp.496-499, Tables 9-16, Model 2.

Moments:
    Kuik F, de Haan JF, Hovenier JW, 1992: Benchmark results for single scattering by spheroids, JQSRT v.47(6), p.477-489.
    See p.482, Table 6.

Comment:
    Horizontal direction, mu = +/-0.0, are ignored in this test.