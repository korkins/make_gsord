RT code:
    Evans KF and Stephens GL, 1991: A new polarized atmopsheric radiative transfer model, JQSRT, v.46(5), p.413-423.
    http://nit.colorado.edu/polrad.html

Comments:
    See T009_RT3.jpg, in.lay, and r09.sca for the RT3 input. See T009_RT3.out for the original RT3 output.
    
    *** U(RT3) = -U(SORD) ***