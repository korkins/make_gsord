Scenario:
    Emde C et al, 2015: IPRT polarized radiative transfer model intercomparison project � Phase A, JQSRT, v.164, pp.8-36.
    See p.23, Section 3.2.6.

Except for: Nadal-Breon vegetation model, ~ 1/(mu_i + mu_v), NOT ocean from IPRT


Comments:
    See also CaseA6.pdf and http://www.meteo.physik.uni-muenchen.de/~iprt/doku.php?id=intercomparisons:a6_ocean1
    The benchmark result was generated with IPOL.

