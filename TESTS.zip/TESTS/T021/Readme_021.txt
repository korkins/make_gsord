Scenario:
    Emde C et al, 2015: IPRT polarized radiative transfer model intercomparison project � Phase A, JQSRT, v.164, pp.8-36.
    See p.19, Section 3.2.1.

Comments:
    See also CaseA1_3.pdf and http://www.meteo.physik.uni-muenchen.de/~iprt/doku.php?id=intercomparisons:a1_rayleigh
    The benchmark result was generated with IPOL.