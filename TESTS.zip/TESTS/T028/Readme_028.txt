Scenario:
    Kokhanovsky et al, 2010: Benchmark results in vector atmospheric radiative transfer, v.111, pp.1931-1946.
    See Section 3, p.1936.

Moments:
    See folder with the benchmark.

Comments:
    1. According to the 'definition_of_cases.pdf' file, sign of Q and U was changed to the
       opposite for some reasons.
    2. Results are avalibale from http://www.iup.uni-bremen.de/~alexk/ (accessed 28Jan15)
    3. See aerosol_refl_N_240.dat and aerosol_trans_N_240.txt for original results.